package com.covalense.springboot.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.springboot.dto.EmployeeAddressInfo;
import com.covalense.springboot.dto.EmployeeEducationalInfoBean;
import com.covalense.springboot.dto.EmployeeExperienceInfoBean;
import com.covalense.springboot.dto.EmployeeInfoBean;
import com.covalense.springboot.dto.EmployeeResponse;
import com.covalense.springboot.repository.EmployeeRepository;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeRepository repository;

	@GetMapping(path = "/", produces = MediaType.TEXT_PLAIN_VALUE)
	public String helloWorld() {
		return "Hello World!!";

	}

	@PostMapping(path = "/create", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse createEmployee(EmployeeInfoBean infoBean) {
		infoBean.getEmployeeOtherBean().setInfoBean(infoBean);

		for (EmployeeAddressInfo addressInfo : infoBean.getAddressInfos()) {
			addressInfo.getAddressPKBean().setInfoBean(infoBean);
		}

		for (EmployeeEducationalInfoBean educationalInfoBean : infoBean.getEducationaInfo()) {
			educationalInfoBean.getEmployeeEducationalPKBean().setInfoBean(infoBean);
		}
		for (EmployeeExperienceInfoBean experienceInfoBean : infoBean.getExperienceInfoBean()) {
			experienceInfoBean.getEmployeeExperiencePKBean().setInfoBean(infoBean);
		}

		EmployeeInfoBean manager = infoBean.getManagerid();
		manager = repository.findById(manager.getId()).get();
		infoBean.setManagerid(manager);

		EmployeeResponse response = new EmployeeResponse();
		if (!repository.existsById(infoBean.getId())) {
			repository.save(infoBean);
			response.setStatusCode(201);
			response.setMessage("successfull");
			response.setDec("Employee data inserted successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDec("Employee Data not added to DB");
		}
		return response;
	}

	@DeleteMapping(path = "/delete",produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse deleteEmployee(EmployeeInfoBean infoBean) {

		EmployeeResponse response = new EmployeeResponse();
		if (repository.existsById(infoBean.getId())) {
			repository.delete(infoBean);
			response.setStatusCode(201);
			response.setMessage("successfull");
			response.setDec("Employee data deleted successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDec("unable to delete employee data from DB");
		}
		return response;
	}
	
	

	@GetMapping(path = "/get", produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse getEmployee(int id) {
		EmployeeResponse response = new EmployeeResponse();
		if (repository.existsById(id)) {
			EmployeeInfoBean infoBean = repository.findById(id).get();
			response.setStatusCode(201);
			response.setMessage("successful");
			response.setDec("Employee data inserted successfully");
			response.setBeans(Arrays.asList(infoBean));
		} else {
			response.setStatusCode(401);
			response.setMessage("failed");
			response.setDec("Employee Data Not Found......");
		}
		return response;
	}
	
	@PutMapping(path = "/update",
			produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse updateEmployee(EmployeeInfoBean infoBean) {
		EmployeeResponse response = new EmployeeResponse();
		if (repository.existsById(infoBean.getId())) {
		repository.save(infoBean);
		response.setStatusCode(201);
		response.setMessage("successful");
		response.setDec("Employee data inserted successfully");
		response.setBeans(Arrays.asList(infoBean));
		}
		return response;
		
		
	}
}
