package com.covalense.librarymgnt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.covalense.librarymgnt.beans.UserDetailsBean;

public interface UserRepository extends CrudRepository<UserDetailsBean, Integer> {
	
	@Query("select e from UserDetailsBean e") 
	public List<UserDetailsBean> findAllUsers();
	
	
}
