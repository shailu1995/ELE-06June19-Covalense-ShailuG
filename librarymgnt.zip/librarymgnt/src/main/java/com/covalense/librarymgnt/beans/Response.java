package com.covalense.librarymgnt.beans;

import java.util.List;

import com.covalense.librarymgnt.beans.UserDetailsBean;

import lombok.Data;

@Data
public class Response {
	
	private int statusCode;
	
	private String message;
	
	private String description;
	
	private UserDetailsBean userDetailsBean;
	
	private List<UserDetailsBean> userDetailsBeans;
	
}
